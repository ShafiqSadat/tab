do local _ = {
  enabled_plugins = {
    "botmanager",
    "tabchi",
    "echo"
  },
  moderation = {
    data = "data/moderation.json"
  },
  sudo_users = {
    238564435
  }
}
return _
end